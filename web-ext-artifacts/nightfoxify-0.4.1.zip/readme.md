Nightfoxify
###############################################################################
Firefox add-on for night mode. Adds a button on the browser toolbar which
toggles night mode on/off. Meaning that backgrounds turn dark gray and most of
the text switches to white font color.

Mozilla Addons link:
https://addons.mozilla.org/en-US/developers/addon/nightfoxify

Github repo:
https://github.com/Juz3/nightfoxify

See web-ext documentation for running and buiding.

###############################################################################

version 0.4 notes:

- The whole action is now in the browserAction button without popup.
  Otherwise same as 0.3.

version 0.4.1 notes:

- added toolbar icon change when toggled on/off.
  Changed color schemes and added some css.
